#!/usr/bin/env python3
"""
DevForge AI - Model Training Pipeline
=======================================
Fine-tunes a base coding model (DeepSeek-Coder or CodeLlama) on UI/app generation.

Usage:
    # Quick start with DeepSeek-Coder 6.7B (recommended):
    python3 train.py --base deepseek-ai/deepseek-coder-6.7b-instruct --output ./devforge-model

    # With CodeLlama:
    python3 train.py --base codellama/CodeLlama-7b-Instruct-hf --output ./devforge-model

Requirements:
    pip install transformers datasets peft trl accelerate bitsandbytes torch wandb
    GPU: Minimum 16GB VRAM (RTX 3090 / 4090 recommended)
    RAM: 32GB+
"""

import os
import json
import argparse
import logging
from dataclasses import dataclass, field
from typing import Optional, List, Dict

import torch
from datasets import Dataset, load_dataset
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    TrainingArguments,
    BitsAndBytesConfig,
)
from peft import LoraConfig, get_peft_model, TaskType, prepare_model_for_kbit_training
from trl import SFTTrainer

logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")
log = logging.getLogger("devforge-train")

# ─────────────────────────────────────────────────────────────────────────────
# Training Dataset Builder
# ─────────────────────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """You are DevForge AI, the world's best app and website developer.
You specialize in creating beautiful, production-ready applications with:
- Perfect color harmony using the 60-30-10 color rule
- Responsive, accessible layouts
- Smooth animations and micro-interactions
- Clean, well-commented code
- Modern design patterns and frameworks

You support: Web Apps (React), Websites (HTML/CSS/JS), Android Apps (Kotlin/Compose), Desktop Apps (Electron).
Always output complete, working code. Never use placeholders."""

def build_training_sample(app_type: str, prompt: str, code: str) -> Dict:
    """Format a single training example."""
    type_context = {
        "web":     "React + Vite + Tailwind CSS web application",
        "website": "pure HTML/CSS/JavaScript website",
        "android": "Kotlin + Jetpack Compose Android application",
        "desktop": "Electron + React desktop application",
    }
    user_msg = f"Create a {type_context[app_type]}: {prompt}"
    return {
        "messages": [
            {"role": "system",    "content": SYSTEM_PROMPT},
            {"role": "user",      "content": user_msg},
            {"role": "assistant", "content": code},
        ]
    }

def load_training_data(data_dir: Optional[str] = None) -> Dataset:
    """
    Load training data. If data_dir is provided, load from JSON files.
    Otherwise, use a small synthetic starter dataset.
    
    Your data files should be JSON arrays of objects:
    [{"app_type": "web", "prompt": "...", "code": "..."}]
    """
    samples = []

    if data_dir and os.path.exists(data_dir):
        log.info(f"📂 Loading custom data from {data_dir}")
        for fname in os.listdir(data_dir):
            if fname.endswith(".json"):
                with open(os.path.join(data_dir, fname)) as f:
                    items = json.load(f)
                    for item in items:
                        samples.append(build_training_sample(
                            item["app_type"], item["prompt"], item["code"]
                        ))
        log.info(f"   Loaded {len(samples)} examples from custom data")
    else:
        log.info("📦 Using built-in starter training data")
        # Starter examples (expand with your own data for better results)
        starter = [
            ("web", "a todo app with dark theme, gradient buttons, and smooth animations",
             """import React, { useState } from 'react';
const TodoApp = () => {
  const [todos, setTodos] = useState([]);
  const [input, setInput] = useState('');
  const add = () => { if(input.trim()){setTodos([...todos,{id:Date.now(),text:input,done:false}]);setInput('');} };
  const toggle = id => setTodos(todos.map(t => t.id===id?{...t,done:!t.done}:t));
  return (
    <div style={{minHeight:'100vh',background:'#0a0a14',display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'sans-serif'}}>
      <div style={{width:360,background:'#12121e',borderRadius:16,padding:24,border:'1px solid #1e1e3a'}}>
        <h1 style={{color:'#e2e8f0',margin:'0 0 20px',fontSize:24}}>Tasks</h1>
        <div style={{display:'flex',gap:8,marginBottom:20}}>
          <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&add()} placeholder="New task..." style={{flex:1,background:'#1e1e3a',border:'1px solid #2a2a4a',borderRadius:8,padding:'10px 14px',color:'#e2e8f0',outline:'none'}}/>
          <button onClick={add} style={{padding:'10px 18px',background:'linear-gradient(135deg,#6366f1,#8b5cf6)',border:'none',borderRadius:8,color:'#fff',fontWeight:700,cursor:'pointer'}}>Add</button>
        </div>
        {todos.map(t=>(
          <div key={t.id} onClick={()=>toggle(t.id)} style={{padding:'12px 16px',background:'#1a1a2e',borderRadius:10,marginBottom:8,cursor:'pointer',border:'1px solid #2a2a4a',display:'flex',gap:12,alignItems:'center'}}>
            <div style={{width:18,height:18,borderRadius:'50%',border:'2px solid',borderColor:t.done?'#6366f1':'#374151',background:t.done?'#6366f1':'transparent',display:'flex',alignItems:'center',justifyContent:'center',fontSize:10}}>{t.done?'✓':''}</div>
            <span style={{color:t.done?'#475569':'#e2e8f0',textDecoration:t.done?'line-through':'none'}}>{t.text}</span>
          </div>
        ))}
      </div>
    </div>
  );
};
export default TodoApp;"""),
            ("website", "a portfolio website for a photographer with elegant dark theme",
             """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Portfolio</title>
  <style>
    *{margin:0;padding:0;box-sizing:border-box}
    body{background:#0a0a0a;color:#f5f5f5;font-family:'Georgia',serif}
    nav{position:fixed;top:0;width:100%;padding:24px 48px;display:flex;justify-content:space-between;align-items:center;z-index:100;background:linear-gradient(#0a0a0aaa,transparent)}
    .logo{font-size:20px;letter-spacing:4px;color:#d4af37}
    .links{display:flex;gap:32px;font-size:13px;letter-spacing:2px;color:#888}
    .links a{color:inherit;text-decoration:none;transition:.2s} .links a:hover{color:#d4af37}
    .hero{height:100vh;display:flex;align-items:center;justify-content:center;text-align:center;background:linear-gradient(135deg,#0a0a0a,#1a1200)}
    h1{font-size:5rem;letter-spacing:-2px;color:#d4af37;margin-bottom:16px}
    .sub{font-size:14px;letter-spacing:6px;color:#666;text-transform:uppercase}
    .gallery{display:grid;grid-template-columns:repeat(3,1fr);gap:4px;padding:4px}
    .photo{aspect-ratio:1;background:linear-gradient(135deg,#1a1a1a,#2a2a2a);overflow:hidden;cursor:pointer}
    .photo:hover{filter:brightness(1.2)}
  </style>
</head>
<body>
  <nav><span class="logo">LENS</span><div class="links"><a href="#">Work</a><a href="#">About</a><a href="#">Contact</a></div></nav>
  <section class="hero"><div><h1>Visual Stories</h1><p class="sub">Photography & Direction</p></div></section>
  <section class="gallery">
    <div class="photo" style="background:linear-gradient(135deg,#1a2030,#2a3040)"></div>
    <div class="photo" style="background:linear-gradient(135deg,#201a30,#302a40)"></div>
    <div class="photo" style="background:linear-gradient(135deg,#1a3020,#2a4030)"></div>
    <div class="photo" style="background:linear-gradient(135deg,#302010,#402820)"></div>
    <div class="photo" style="background:linear-gradient(135deg,#101030,#202050)"></div>
    <div class="photo" style="background:linear-gradient(135deg,#201010,#402020)"></div>
  </section>
</body>
</html>"""),
        ]
        for (app_type, prompt, code) in starter:
            samples.append(build_training_sample(app_type, prompt, code))

    log.info(f"📊 Total training samples: {len(samples)}")
    return Dataset.from_list(samples)

# ─────────────────────────────────────────────────────────────────────────────
# Training
# ─────────────────────────────────────────────────────────────────────────────

def format_chat(sample: Dict) -> str:
    """Convert messages list to a single training string."""
    text = ""
    for m in sample["messages"]:
        if m["role"] == "system":
            text += f"<|system|>\n{m['content']}\n"
        elif m["role"] == "user":
            text += f"<|user|>\n{m['content']}\n"
        elif m["role"] == "assistant":
            text += f"<|assistant|>\n{m['content']}\n<|endoftext|>"
    return text

def train(
    base_model: str,
    output_dir: str,
    data_dir: Optional[str],
    epochs: int,
    batch_size: int,
    lr: float,
    use_4bit: bool,
):
    log.info("=" * 60)
    log.info("  DevForge AI — Training Pipeline")
    log.info("=" * 60)
    log.info(f"  Base model : {base_model}")
    log.info(f"  Output     : {output_dir}")
    log.info(f"  Epochs     : {epochs}")
    log.info(f"  Batch size : {batch_size}")
    log.info(f"  LR         : {lr}")
    log.info(f"  4-bit quant: {use_4bit}")
    log.info("=" * 60)

    # ── Dataset ──────────────────────────────────────────────────
    dataset = load_training_data(data_dir)
    dataset = dataset.map(lambda x: {"text": format_chat(x)})

    # ── Quantization ─────────────────────────────────────────────
    bnb_config = None
    if use_4bit:
        log.info("⚙️  Configuring 4-bit quantization (QLoRA)...")
        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16,
            bnb_4bit_use_double_quant=True,
        )

    # ── Tokenizer ────────────────────────────────────────────────
    log.info("📦 Loading tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(base_model, trust_remote_code=True)
    tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"

    # ── Model ────────────────────────────────────────────────────
    log.info("🤖 Loading base model...")
    model = AutoModelForCausalLM.from_pretrained(
        base_model,
        quantization_config=bnb_config,
        device_map="auto",
        trust_remote_code=True,
        torch_dtype=torch.bfloat16 if not use_4bit else None,
    )

    if use_4bit:
        model = prepare_model_for_kbit_training(model)

    # ── LoRA ─────────────────────────────────────────────────────
    log.info("🔗 Attaching LoRA adapters...")
    lora_config = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=16,                        # rank
        lora_alpha=32,               # scaling
        target_modules=["q_proj", "v_proj", "k_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
        lora_dropout=0.05,
        bias="none",
    )
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()

    # ── Training Args ─────────────────────────────────────────────
    training_args = TrainingArguments(
        output_dir=output_dir,
        num_train_epochs=epochs,
        per_device_train_batch_size=batch_size,
        gradient_accumulation_steps=4,
        gradient_checkpointing=True,
        optim="paged_adamw_32bit",
        learning_rate=lr,
        lr_scheduler_type="cosine",
        warmup_ratio=0.05,
        weight_decay=0.01,
        fp16=not use_4bit,
        bf16=False,
        max_grad_norm=0.3,
        logging_steps=10,
        save_steps=100,
        save_total_limit=2,
        evaluation_strategy="no",
        report_to="none",
        dataloader_num_workers=4,
    )

    # ── Trainer ───────────────────────────────────────────────────
    trainer = SFTTrainer(
        model=model,
        tokenizer=tokenizer,
        train_dataset=dataset,
        args=training_args,
        dataset_text_field="text",
        max_seq_length=4096,
        packing=True,
    )

    # ── Train ─────────────────────────────────────────────────────
    log.info("🚀 Starting training...")
    trainer.train()

    # ── Save ──────────────────────────────────────────────────────
    log.info(f"💾 Saving model to {output_dir}...")
    trainer.save_model(output_dir)
    tokenizer.save_pretrained(output_dir)

    log.info("=" * 60)
    log.info("  ✅  Training complete!")
    log.info(f"  Model saved to: {output_dir}")
    log.info("  Run the server: python3 server.py --model " + output_dir)
    log.info("=" * 60)

# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="DevForge AI Training Pipeline")
    parser.add_argument("--base",   default="deepseek-ai/deepseek-coder-6.7b-instruct", help="Base model HuggingFace ID")
    parser.add_argument("--output", default="./devforge-model",  help="Where to save the fine-tuned model")
    parser.add_argument("--data",   default=None,                help="Path to custom training data directory (JSON files)")
    parser.add_argument("--epochs", type=int,   default=3,       help="Number of training epochs")
    parser.add_argument("--batch",  type=int,   default=2,       help="Per-device batch size")
    parser.add_argument("--lr",     type=float, default=2e-4,    help="Learning rate")
    parser.add_argument("--no-4bit", action="store_true",        help="Disable 4-bit quantization (needs more VRAM)")
    args = parser.parse_args()

    train(
        base_model=args.base,
        output_dir=args.output,
        data_dir=args.data,
        epochs=args.epochs,
        batch_size=args.batch,
        lr=args.lr,
        use_4bit=not args.no_4bit,
    )
