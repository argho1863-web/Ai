# DevForge AI — Complete Setup Guide

## What's Included

| File | Purpose |
|------|---------|
| `app.jsx` | The Lovable-style interface (React) |
| `server.py` | Ubuntu local model API server |
| `train.py` | Model fine-tuning pipeline |
| `requirements.txt` | Python dependencies |

---

## Part 1 — Train Your Model (Ubuntu)

### Prerequisites
- Ubuntu 20.04+
- Python 3.10+
- NVIDIA GPU with 16GB+ VRAM (RTX 3090/4090 ideal)
- CUDA 11.8+

### Install dependencies
```bash
pip install transformers datasets peft trl accelerate bitsandbytes torch fastapi uvicorn pydantic
```

### Run training
```bash
# Using DeepSeek-Coder 6.7B (recommended)
python3 train.py \
  --base deepseek-ai/deepseek-coder-6.7b-instruct \
  --output ./devforge-model \
  --epochs 3

# Optional: Add your own training data
python3 train.py --base deepseek-ai/deepseek-coder-6.7b-instruct \
                 --output ./devforge-model \
                 --data ./my_training_data/
```

### Custom training data format
Create JSON files in a folder:
```json
[
  {
    "app_type": "web",
    "prompt": "a weather dashboard with animated icons",
    "code": "// your complete code here"
  }
]
```
`app_type` can be: `web`, `website`, `android`, `desktop`

---

## Part 2 — Run the API Server (Ubuntu)

```bash
python3 server.py --model ./devforge-model --port 8080
```

**On startup, the console will print:**
```
────────────────────────────────────────────────────────────
  🔑  YOUR API KEY (copy this into DevForge app):

      dfk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

  Endpoint:
      http://0.0.0.0:8080/v1
────────────────────────────────────────────────────────────
```

Copy this key — you'll paste it into the DevForge app.

---

## Part 3 — Use the Interface

### Option A: Run locally (recommended)
```bash
# Create a Vite React project
npm create vite@latest devforge-ui -- --template react
cd devforge-ui
cp /path/to/app.jsx src/App.jsx
npm install
npm run dev
# Open http://localhost:5173
```

### Option B: Deploy to Vercel / Netlify
```bash
npm run build
# Upload dist/ folder
```

---

## Part 4 — Connect Your Model

1. Open the DevForge app in your browser
2. Click **🤖 Add AI Model** in the top right
3. Choose **Local Model** tab
4. Enter a name (e.g. "My DevForge Model")
5. Paste the endpoint: `http://YOUR_UBUNTU_IP:8080/v1`
6. Paste the API key from the console
7. Click **Add** then **Use**

---

## API Reference

The server exposes an OpenAI-compatible API:

```bash
# Chat completions (standard)
curl http://localhost:8080/v1/chat/completions \
  -H "Authorization: Bearer YOUR_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"devforge","messages":[{"role":"user","content":"Build a login page"}]}'

# App generation (specialized)
curl http://localhost:8080/v1/generate \
  -H "Authorization: Bearer YOUR_KEY" \
  -H "Content-Type: application/json" \
  -d '{"prompt":"a task manager","app_type":"web","style":"dark minimal"}'
```

---

## Tips for Best Results

- **More training data = better quality.** Collect real UI codebases from GitHub.
- **Use 4-bit quantization** (`--no-4bit` flag disabled) to fit on a single GPU.
- **Restart the server** to get a fresh API key each time (or save from `.devforge_api_key` file).
- For Android apps, add Kotlin + Jetpack Compose examples to your training data.
- For desktop apps, add Electron boilerplates to your data.
