#!/usr/bin/env python3
"""
DevForge AI - Local Model API Server
=====================================
Run this on Ubuntu to start your fine-tuned model as an API server.
The generated API key will be printed to console on startup.

Usage:
    python3 server.py --model ./devforge-model --port 8080

Requirements:
    pip install fastapi uvicorn transformers torch accelerate peft secrets
"""

import os
import sys
import secrets
import argparse
import logging
from datetime import datetime
from typing import Optional, List

# ── FastAPI ──────────────────────────────────────────────────────────────────
from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn

# ── ML ───────────────────────────────────────────────────────────────────────
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
from peft import PeftModel
import torch

# ─────────────────────────────────────────────────────────────────────────────
logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")
log = logging.getLogger("devforge")

# ── Generate API Key ──────────────────────────────────────────────────────────
API_KEY = "dfk-" + secrets.token_urlsafe(32)

# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(title="DevForge AI Server", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ── Global model state ────────────────────────────────────────────────────────
MODEL = None
TOKENIZER = None
PIPE = None

# ── Schemas ───────────────────────────────────────────────────────────────────
class Message(BaseModel):
    role: str   # "user" | "assistant" | "system"
    content: str

class ChatRequest(BaseModel):
    model: str = "devforge"
    messages: List[Message]
    max_tokens: int = 2048
    temperature: float = 0.7
    stream: bool = False

class GenerateRequest(BaseModel):
    prompt: str
    app_type: str = "web"   # web | website | android | desktop
    style: Optional[str] = None
    colors: Optional[str] = None
    max_tokens: int = 4096

# ── Auth ──────────────────────────────────────────────────────────────────────
def require_api_key(authorization: str = Header(...)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid auth header format")
    key = authorization.split(" ", 1)[1]
    if key != API_KEY:
        raise HTTPException(status_code=403, detail="Invalid API key")
    return key

# ── Routes ────────────────────────────────────────────────────────────────────
@app.get("/")
def root():
    return {"name": "DevForge AI Server", "status": "running", "docs": "/docs"}

@app.get("/v1/models", dependencies=[Depends(require_api_key)])
def list_models():
    return {"object": "list", "data": [{"id": "devforge", "object": "model", "created": 1700000000}]}

@app.post("/v1/chat/completions", dependencies=[Depends(require_api_key)])
def chat(req: ChatRequest):
    if PIPE is None:
        raise HTTPException(status_code=503, detail="Model not loaded yet")
    
    # Build prompt
    conversation = ""
    for m in req.messages:
        if m.role == "system":
            conversation += f"<|system|>\n{m.content}\n"
        elif m.role == "user":
            conversation += f"<|user|>\n{m.content}\n"
        elif m.role == "assistant":
            conversation += f"<|assistant|>\n{m.content}\n"
    conversation += "<|assistant|>\n"

    output = PIPE(
        conversation,
        max_new_tokens=req.max_tokens,
        temperature=req.temperature,
        do_sample=True,
        pad_token_id=TOKENIZER.eos_token_id,
    )
    text = output[0]["generated_text"].split("<|assistant|>\n")[-1].strip()

    return {
        "id": f"chatcmpl-{secrets.token_hex(8)}",
        "object": "chat.completion",
        "model": "devforge",
        "choices": [{"index": 0, "message": {"role": "assistant", "content": text}, "finish_reason": "stop"}],
        "usage": {"prompt_tokens": len(conversation.split()), "completion_tokens": len(text.split()), "total_tokens": 0},
    }

@app.post("/v1/generate", dependencies=[Depends(require_api_key)])
def generate_app(req: GenerateRequest):
    """Specialized endpoint for app/website generation."""
    if PIPE is None:
        raise HTTPException(status_code=503, detail="Model not loaded yet")

    system = """You are DevForge AI, an expert full-stack developer and designer.
You write production-ready, beautiful code for apps and websites.
You follow these rules:
1. Use the most reliable, harmonious color combinations (60-30-10 rule)
2. Write complete, working code — no placeholders
3. Add thoughtful animations and micro-interactions
4. Ensure full responsiveness
5. Use modern frameworks and best practices
6. Generate descriptive comments
Always output ONLY the code, wrapped in a single markdown code block."""

    type_guides = {
        "web":     "React + Vite app with Tailwind CSS",
        "website": "Vanilla HTML/CSS/JS website",
        "android": "Kotlin + Jetpack Compose Android app",
        "desktop": "Electron + React desktop app",
    }

    prompt = f"""{system}

App Type: {type_guides.get(req.app_type, 'web app')}
Style: {req.style or 'modern, clean, professional'}
Colors: {req.colors or 'choose the best palette for this app'}

Request: {req.prompt}"""

    output = PIPE(
        prompt,
        max_new_tokens=req.max_tokens,
        temperature=0.6,
        do_sample=True,
        pad_token_id=TOKENIZER.eos_token_id,
    )
    code = output[0]["generated_text"][len(prompt):].strip()

    return {"app_type": req.app_type, "code": code, "model": "devforge"}

# ── Model Loader ──────────────────────────────────────────────────────────────
def load_model(model_path: str, use_lora: bool = False):
    global MODEL, TOKENIZER, PIPE
    log.info(f"📦 Loading model from: {model_path}")

    TOKENIZER = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
    if TOKENIZER.pad_token is None:
        TOKENIZER.pad_token = TOKENIZER.eos_token

    MODEL = AutoModelForCausalLM.from_pretrained(
        model_path,
        torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
        device_map="auto",
        trust_remote_code=True,
    )

    if use_lora:
        log.info("🔗 Loading LoRA adapter weights...")
        MODEL = PeftModel.from_pretrained(MODEL, model_path + "/lora_adapter")

    PIPE = pipeline("text-generation", model=MODEL, tokenizer=TOKENIZER)
    log.info("✅ Model loaded successfully")

# ── Main ──────────────────────────────────────────────────────────────────────
def print_banner():
    print("\n" + "═" * 60)
    print("  ██████╗ ███████╗██╗   ██╗███████╗ ██████╗ ██████╗  ██████╗ ███████╗")
    print("  ██╔══██╗██╔════╝██║   ██║██╔════╝██╔═══██╗██╔══██╗██╔════╝ ██╔════╝")
    print("  ██║  ██║█████╗  ██║   ██║█████╗  ██║   ██║██████╔╝██║  ███╗█████╗  ")
    print("  ██║  ██║██╔══╝  ╚██╗ ██╔╝██╔══╝  ██║   ██║██╔══██╗██║   ██║██╔══╝  ")
    print("  ██████╔╝███████╗ ╚████╔╝ ██║     ╚██████╔╝██║  ██║╚██████╔╝███████╗")
    print("  ╚═════╝ ╚══════╝  ╚═══╝  ╚═╝      ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚══════╝")
    print("═" * 60)
    print("  🤖  DevForge AI — Local Model Server")
    print("═" * 60)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="DevForge AI Model Server")
    parser.add_argument("--model", default="./devforge-model", help="Path to model directory")
    parser.add_argument("--port", type=int, default=8080, help="Port to listen on")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind to")
    parser.add_argument("--lora", action="store_true", help="Load LoRA adapter weights")
    args = parser.parse_args()

    print_banner()

    # ──────────────────────────────────────────────────────────────
    print("\n" + "─" * 60)
    print("  🔑  YOUR API KEY (copy this into DevForge app):")
    print()
    print(f"      {API_KEY}")
    print()
    print("  Endpoint:")
    print(f"      http://{args.host}:{args.port}/v1")
    print("─" * 60 + "\n")
    # ──────────────────────────────────────────────────────────────

    # Load model
    if os.path.exists(args.model):
        load_model(args.model, use_lora=args.lora)
    else:
        log.warning(f"⚠️  Model path '{args.model}' not found. API will return 503 until model is loaded.")
        log.warning("    Train your model first: python3 train.py")

    # Save key to file for convenience
    with open(".devforge_api_key", "w") as f:
        f.write(API_KEY)
    log.info("💾 API key also saved to .devforge_api_key")

    # Start server
    log.info(f"🚀 Starting server at http://{args.host}:{args.port}")
    uvicorn.run(app, host=args.host, port=args.port, log_level="warning")
